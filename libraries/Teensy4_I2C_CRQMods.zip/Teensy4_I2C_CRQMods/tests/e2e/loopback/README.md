These tests check that the I2C driver works when the Teensy talks to itself.

See loopback.h for details of the board setup.

See tests\board_design\loopback.perf_board.4.1.fzz for the as built test board.