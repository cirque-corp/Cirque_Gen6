# Test Harnesses
This directory contains test harnesses which can be used
to exercises the examples.

# Index
## raspberry_pi
Contains Python scripts that will run on a Raspberry Pi.
Raspberry Pi 4 and older cannot act as I2C slaves so these
scripts can only be used for testing the Teensy in slave mode.
